package com.beaconfire.quizonline.domain.jdbc;

import com.beaconfire.quizonline.domain.Contact;
import lombok.*;

@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class ContactJdbc extends Contact {
}
