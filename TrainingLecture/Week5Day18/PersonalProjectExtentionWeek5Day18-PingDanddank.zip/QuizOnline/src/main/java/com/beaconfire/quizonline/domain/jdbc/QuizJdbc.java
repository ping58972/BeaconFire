package com.beaconfire.quizonline.domain.jdbc;

import com.beaconfire.quizonline.domain.Quiz;
import lombok.*;

@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class QuizJdbc extends Quiz {
}
