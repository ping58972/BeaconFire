package com.beaconfire.quizonline.domain.jdbc;

import com.beaconfire.quizonline.domain.Category;
import lombok.*;

@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class CategoryJdbc extends Category {
}
