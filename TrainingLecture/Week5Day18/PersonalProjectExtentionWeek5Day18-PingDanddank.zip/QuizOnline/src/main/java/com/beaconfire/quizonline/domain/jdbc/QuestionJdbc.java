package com.beaconfire.quizonline.domain.jdbc;

import com.beaconfire.quizonline.domain.Question;
import lombok.*;

@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class QuestionJdbc extends Question {
}
