package com.beaconfire.quizonline.domain.jdbc;

import com.beaconfire.quizonline.domain.Feedback;
import lombok.*;

@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class FeedbackJdbc extends Feedback {
}
