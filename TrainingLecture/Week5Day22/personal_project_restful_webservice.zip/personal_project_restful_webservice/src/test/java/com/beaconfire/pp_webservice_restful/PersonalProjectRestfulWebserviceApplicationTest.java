package com.beaconfire.pp_webservice_restful;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class PersonalProjectRestfulWebserviceApplicationTest {

    @Test
    void contextLoads() {
    }
}