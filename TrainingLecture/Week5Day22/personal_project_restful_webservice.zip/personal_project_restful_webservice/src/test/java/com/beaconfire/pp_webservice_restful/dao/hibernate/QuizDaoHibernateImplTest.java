package com.beaconfire.pp_webservice_restful.dao.hibernate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QuizDaoHibernateImplTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getCurrentSession() {
    }

    @Test
    void setClazz() {
    }

    @Test
    void getAll() {
    }

    @Test
    void findById() {
    }

    @Test
    void add() {
    }

    @Test
    void getAllQuizzes() {
    }

    @Test
    void getAllQuizzesByUserId() {
    }
}