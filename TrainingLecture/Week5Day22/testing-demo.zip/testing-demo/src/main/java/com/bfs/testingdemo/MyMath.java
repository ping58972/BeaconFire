package com.bfs.testingdemo;

public class MyMath {

    public int doubleNumber(int x) {
        return x*2;
    }

    public int squareNumber(int x) {
        return x * x;
    }
}