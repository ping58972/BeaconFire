package com.bfs.testingdemo.exception;

public class DataNotFoundException extends Exception{
    public DataNotFoundException(String message) {
        super(message);
    }
}