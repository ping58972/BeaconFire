package com.bfs.testingdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
