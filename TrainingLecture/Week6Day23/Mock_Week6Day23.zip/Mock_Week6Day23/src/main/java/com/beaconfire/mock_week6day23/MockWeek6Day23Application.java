package com.beaconfire.mock_week6day23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockWeek6Day23Application {

    public static void main(String[] args) {
        SpringApplication.run(MockWeek6Day23Application.class, args);
    }

}
