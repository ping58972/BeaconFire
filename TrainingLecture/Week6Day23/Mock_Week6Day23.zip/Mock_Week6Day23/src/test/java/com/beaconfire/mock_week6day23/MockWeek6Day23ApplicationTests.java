package com.beaconfire.mock_week6day23;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockWeek6Day23ApplicationTests {

    @Test
    void contextLoads() {
    }

}
