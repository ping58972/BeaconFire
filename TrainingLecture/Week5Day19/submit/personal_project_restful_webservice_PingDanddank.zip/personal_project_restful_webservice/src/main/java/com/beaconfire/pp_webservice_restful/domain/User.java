package com.beaconfire.pp_webservice_restful.domain;


public abstract class User {

}
