package com.beaconfire.springsecuritycontent.domain.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContentCreationRequest {
    Integer id;
    String content;
}
