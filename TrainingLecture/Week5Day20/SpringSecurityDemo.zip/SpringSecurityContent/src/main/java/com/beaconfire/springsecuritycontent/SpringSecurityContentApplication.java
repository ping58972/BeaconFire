package com.beaconfire.springsecuritycontent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityContentApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityContentApplication.class, args);
    }

}
