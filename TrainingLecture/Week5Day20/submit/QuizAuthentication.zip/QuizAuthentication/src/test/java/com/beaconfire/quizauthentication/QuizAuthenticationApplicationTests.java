package com.beaconfire.quizauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizAuthenticationApplicationTests {

    @Test
    void contextLoads() {
    }

}
