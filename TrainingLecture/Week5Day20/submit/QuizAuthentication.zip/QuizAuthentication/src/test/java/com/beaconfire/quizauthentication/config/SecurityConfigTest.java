package com.beaconfire.quizauthentication.config;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SecurityConfigTest {

    @Test
    void setUserDetailsService() {
    }

    @Test
    void daoAuthenticationProvider() {
    }

    @Test
    void authenticationManager() {
    }

    @Test
    void configure() {
    }
}