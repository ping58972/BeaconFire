package com.beaconfire.pp_webservice_restful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonalProjectRestfulWebserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(PersonalProjectRestfulWebserviceApplication.class, args);
    }

}
