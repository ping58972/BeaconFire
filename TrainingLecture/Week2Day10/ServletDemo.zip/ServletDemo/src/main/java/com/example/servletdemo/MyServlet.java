package com.example.servletdemo;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "MyServlet", urlPatterns = "/my-servlet")
public class MyServlet extends HttpServlet {

    //this method is called when post requests are sent to /my-servlet
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        System.out.println("a POST request was sent to /my-servlet");
    }

    //this method is called when get requests are sent to /my-servlet
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        System.out.println("a GET request was sent to /my-servlet");

        //Set the content type in the header of the HTTP request
        //this just tells the client the type of data being sent
        response.setContentType("text/plain");
        response.getWriter().println("Never gonna give you up");
        response.getWriter().println("Never gonna let you down");

        //Content types: https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types
//        response.setContentType("text/html");
//        response.getWriter().println("<h1>My Servlet</h1>");
//        response.getWriter().println("<h3>Welcome!</h3>");

    }

}
