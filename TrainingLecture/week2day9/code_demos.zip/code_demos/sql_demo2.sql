CREATE DATABASE IF NOT EXISTS sql_demo2;
USE sql_demo2;

DROP TABLE IF EXISTS Animals;

CREATE TABLE IF NOT EXISTS Animals (
	animal_id int auto_increment PRIMARY KEY,
    species varchar(24),
    class varchar(24),
    zoo varchar(24),
    age int,
    weight float
);

INSERT INTO Animals (species, class, zoo, age, weight) VALUES 
('panda', 'mammal', 'Panda Zoo', 2, 50.5),
('panda', 'mammal', 'Panda Zoo', 1, 42),
('giraffe', 'mammal', 'Blue Forest Zoo', 7, 11),
('giraffe', 'mammal', 'Blue Forest Zoo', 4, 5),
('lion', 'mammal', 'Blue Forest Zoo', 5, 8.5),
('eagle', 'avian', 'Blue Forest Zoo', 3, 10.25),
('dolphin', 'aquatic', 'Red Maple Zoo', 2, 5.5),
('goldfish', 'aquatic', 'Red Maple Zoo', 1, 0.5),
('horse', 'mammal', 'Red Maple Zoo', 9, 12);

-- select queries
SELECT * FROM Animals;

SELECT animal_id, species, zoo FROM Animals;

SELECT animal_id, species, zoo AS zoo_name FROM Animals;

-- all different species
SELECT DISTINCT species FROM Animals;
-- number of animals by counting the unique ID
SELECT COUNT(animal_id) FROM Animals;

SELECT COUNT(distinct(species)) FROM Animals;
-- number of animals of class 'mammals'
SELECT COUNT(animal_id) FROM Animals WHERE class = 'mammal';
-- average of all animals' ages
SELECT AVG(age) FROM Animals;
-- total weight of all animals
SELECT SUM(weight) from Animals;

-- ORDER BY, LIMIT queries
SELECT species, weight
FROM Animals
ORDER BY weight DESC
LIMIT 3; 

SELECT species, age, weight
FROM Animals
WHERE zoo = 'Blue Forest Zoo'
ORDER BY age DESC, weight DESC -- order first by age then by weight
LIMIT 3;

-- GROUP BY, HAVING queries
-- list the number of animals in each zoo
SELECT COUNT(animal_id) AS number_of_animals, zoo
FROM Animals
GROUP BY zoo;

-- list the number of animals in each zoo sorted from high to low
SELECT COUNT(animal_id), zoo
FROM Animals
GROUP BY zoo
ORDER BY COUNT(animal_id) DESC;

-- list the number of animals in each zoo sorted high to low
-- only include animals in zoos with more than 1 species type)
SELECT COUNT(animal_id), zoo
FROM Animals
GROUP BY zoo
HAVING COUNT(distinct(species)) > 1
ORDER BY COUNT(animal_id) DESC;



