use aw;

select fis.customerkey, fis.salesamount,
	   case when DATEDIFF('2010-01-01', dc.birthdate) / 365.25 > 70 then "Elder"
			when DATEDIFF('2010-01-01', dc.birthdate) / 365.25 <= 50 then "Younger"
			else 'Middle Age'
       end as Age
 from factinternetsales fis left join dimcustomer dc on fis.customerkey = dc.customerkey;
 