-- in example:
DELIMITER $$

Drop procedure if exists GetCustomer $$

Create Procedure GetCustomer(
	IN currentDate date
)
Begin
	select fis.customerkey, fis.salesamount,
	   case when DATEDIFF(currentDate, dc.birthdate) / 365.25 > 70 then "Elder"
			when DATEDIFF(currentDate, dc.birthdate) / 365.25 <= 50 then "Younger"
			else 'Middle Age'
       end as Age
	from aw.factinternetsales fis left join aw.dimcustomer dc on fis.customerkey = dc.customerkey;	
End$$

DELIMITER ;

call GetCustomer('1991-02-25');

-- out example: 

DELIMITER $$

Drop procedure if exists GetCount $$
Create Procedure GetCount(
	IN categoryName varchar(50),
    OUT count1 int
)
Begin
	select count(*) INTO count1 from beaconfire.products where category = categoryName;
End$$

DELIMITER ;

set @result = 11110;
call GetCount('veggie', @result);
select @result;
