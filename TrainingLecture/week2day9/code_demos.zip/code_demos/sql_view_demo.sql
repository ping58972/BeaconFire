CREATE DATABASE IF NOT EXISTS sql_demo2;
USE sql_demo2;

DROP TABLE IF EXISTS employees;

CREATE TABLE employees (
	id INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    firstname VARCHAR(50),
    lastname VARCHAR(50),
    PRIMARY KEY(id)
);

ALTER TABLE employees 
ALTER firstname SET DEFAULT 'John',
ALTER lastname SET DEFAULT 'Doe';

INSERT INTO employees(username) VALUES('user123'), ('983user'), ('user000'), ('aaa');

-- VIEW example
DROP VIEW IF EXISTS employee_view;

CREATE VIEW employee_view AS 
SELECT id, username, firstname, lastname FROM employees;

SELECT * FROM employee_view;

UPDATE employee_view SET username = 'helloworld' WHERE id=1;
SELECT * FROM employees;