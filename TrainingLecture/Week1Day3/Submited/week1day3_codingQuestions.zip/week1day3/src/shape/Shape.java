package shape;
/*
* @Author: Ping Danddank
* @email: ndanddank@gmail.com
an abstract class named shape that contains integers and
an empty method named printArea.
 */
public abstract class Shape {
    int height, width, radius;

    public abstract void printArea();



}
