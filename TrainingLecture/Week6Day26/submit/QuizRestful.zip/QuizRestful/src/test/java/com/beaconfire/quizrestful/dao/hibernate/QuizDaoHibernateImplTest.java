package com.beaconfire.quizrestful.dao.hibernate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class QuizDaoHibernateImplTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getCurrentSession() {
    }

    @Test
    void setClazz() {
    }

    @Test
    void getAll() {
    }

    @Test
    void findById() {
    }

    @Test
    void add() {
    }

    @Test
    void getAllQuizzes() {
    }

    @Test
    void getAllQuizzesByUserId() {
    }
}