package com.beaconfire.quizrestful.domain;

public abstract class QuizQuestion {
}
