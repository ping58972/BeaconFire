package com.bfs.springdatademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
