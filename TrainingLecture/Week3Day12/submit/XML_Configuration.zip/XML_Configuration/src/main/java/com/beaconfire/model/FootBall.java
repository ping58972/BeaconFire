package com.beaconfire.model;

public class FootBall implements Coach{
    @Override
    public void getDailyWorkOutSchedule() {
        System.out.println("I like to play FootBall!");
    }
}