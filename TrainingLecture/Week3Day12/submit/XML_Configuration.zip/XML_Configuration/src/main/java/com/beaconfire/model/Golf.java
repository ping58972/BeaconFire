package com.beaconfire.model;

public class Golf implements Coach{
    @Override
    public void getDailyWorkOutSchedule() {
        System.out.println("I like to play Golf!");
    }
}
