package com.beaconfire.model;

public interface Coach {
    void getDailyWorkOutSchedule();
}
