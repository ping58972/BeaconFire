package com.beaconfire.model;

import org.springframework.stereotype.Component;

public interface Coach {
    void getDailyWorkOutSchedule();
}
