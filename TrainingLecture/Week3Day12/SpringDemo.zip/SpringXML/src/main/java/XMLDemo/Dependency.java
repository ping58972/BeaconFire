package XMLDemo;

public interface Dependency {
    void printMessage();
}
