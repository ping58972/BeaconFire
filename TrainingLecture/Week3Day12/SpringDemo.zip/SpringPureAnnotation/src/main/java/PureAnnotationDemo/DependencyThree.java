package PureAnnotationDemo;

public class DependencyThree implements Dependency {

    @Override
    public void printMessage() {
        System.out.println("Dependency Three");
    }
}
