package PureAnnotationDemo;

public interface Dependency {
    void printMessage();
}
