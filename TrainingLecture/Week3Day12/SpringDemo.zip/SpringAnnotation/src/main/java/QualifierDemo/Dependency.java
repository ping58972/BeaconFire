package QualifierDemo;

public interface Dependency {
    void printMessage();
}
