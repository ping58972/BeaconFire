package AnnotationDemo;

public interface Dependency {
    void printMessage();
}
