package com.beaconfire.emailapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
