package com.beaconfire.quizonline.domain.jdbc;

import com.beaconfire.quizonline.domain.Choice;
import lombok.*;

@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class ChoiceJdbc extends Choice {
}
