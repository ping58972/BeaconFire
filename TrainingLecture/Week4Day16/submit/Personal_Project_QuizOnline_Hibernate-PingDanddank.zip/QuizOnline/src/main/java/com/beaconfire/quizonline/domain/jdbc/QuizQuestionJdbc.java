package com.beaconfire.quizonline.domain.jdbc;

import com.beaconfire.quizonline.domain.QuizQuestion;
import lombok.*;

@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class QuizQuestionJdbc extends QuizQuestion {
}
