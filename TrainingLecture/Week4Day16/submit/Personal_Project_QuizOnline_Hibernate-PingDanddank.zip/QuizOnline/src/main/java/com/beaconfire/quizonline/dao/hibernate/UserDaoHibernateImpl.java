package com.beaconfire.quizonline.dao.hibernate;

import com.beaconfire.quizonline.dao.UserDao;
import com.beaconfire.quizonline.domain.Address;
import com.beaconfire.quizonline.domain.User;
import com.beaconfire.quizonline.domain.hibernate.AddressHibernate;
import com.beaconfire.quizonline.domain.hibernate.UserHibernate;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository("userDaoHibernateImpl")
@Transactional
public class UserDaoHibernateImpl extends AbstractHibernateDao<UserHibernate> implements UserDao {
    public UserDaoHibernateImpl() {
        setClazz(UserHibernate.class);
    }

    @Override
    public List<User> getAllUsers() {
        Session session = getCurrentSession();
        Query query = session.createQuery("FROM UserHibernate ");
        List<User> qhList = query.list();
        return qhList;
    }

    @Override
    public UserHibernate getUserById(Integer id) {
        UserHibernate user = this.findById(id);
        user.setAddressId(user.getAddress().getAddressId());
        user.setAddressToUser(user.getAddress());
        return user;
    }

    @Override
    public UserHibernate getUserByEmail(String email) {
        Query query = getCurrentSession().createQuery(
                "FROM UserHibernate u WHERE u.email = :email ");
        query.setParameter("email", email);
        List<UserHibernate> list = query.list();
        System.out.println(list);
        if (list.size() == 0) {
            return new UserHibernate();
        }
        UserHibernate user = list.get(0);
        user.setAddressToUser(user.getAddress());
        return user;
    }

    @Override
    public User createNewUser(String firstName, String lastName, String email,
                              String password, String phone, String street, String city,
                              String state, int zipcode, String country) {
        Session session = getCurrentSession();
        AddressHibernate address = new AddressHibernate();
        address.setStreet(street);
        address.setCity(city);
        address.setCountry(country);
        address.setZipcode(zipcode);
        address.setState(state);
        AddressHibernate newAdd = (AddressHibernate) session.merge(address);
        UserHibernate user = new UserHibernate();
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setEmail(email);
        user.setPassword(password);
        user.setPhone(phone);
        user.setAddressId(newAdd.getAddressId());
        user.setAddress(newAdd);
        User newUser = (User) session.merge(user);
        return newUser;
    }

    @Override
    public int deleteUserById(Integer id) {
        Session session = getCurrentSession();
        UserHibernate user = session.get(UserHibernate.class, id);
        session.delete(user);
        return 1;
    }

    @Override
    public int deleteUserByEmail(String email) {
        Session session = getCurrentSession();
        UserHibernate user = getUserByEmail(email);
        session.delete(user);
        return 1;
    }

    @Override
    public User updateUser(Integer id, String firstName, String lastName,
                           String email, String password, boolean isActive,
                           String phone, String street, String city, String state,
                           int zipcode, String country) {
        Session session = getCurrentSession();
        UserHibernate user = session.get(UserHibernate.class, id);
        AddressHibernate address = user.getAddress();
        address.setStreet(street);
        address.setCity(city);
        address.setCountry(country);
        address.setZipcode(zipcode);
        address.setState(state);
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setEmail(email);
        user.setPassword(password);
        user.setPhone(phone);
        UserHibernate newUser = (UserHibernate) session.merge(user);
        newUser.setAddressToUser(newUser.getAddress());
        return newUser;
    }

    @Override
    public int changeActiveById(int id) {
        Session session = getCurrentSession();
        UserHibernate user = session.get(UserHibernate.class, id);
        boolean active = user.isActive();
        user.setActive(!active);
        session.saveOrUpdate(user);
        return 1;
    }

    @Override
    public Address getAddressById(Integer id) {
        Query query = getCurrentSession().createQuery(
                "FROM AddressHibernate add WHERE add.addressId = :id ");
        query.setParameter("id", id);
        List list = query.list();
        return (Address) list.get(0);
    }
}
