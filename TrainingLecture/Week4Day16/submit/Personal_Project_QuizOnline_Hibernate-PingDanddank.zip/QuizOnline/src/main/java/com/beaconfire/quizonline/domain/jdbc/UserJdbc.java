package com.beaconfire.quizonline.domain.jdbc;

import com.beaconfire.quizonline.domain.Address;
import com.beaconfire.quizonline.domain.User;
import lombok.*;

@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
public class UserJdbc extends User {
}
