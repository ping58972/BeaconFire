package com.bfs.hibernateprojectdemo.domain.jdbc;

import com.bfs.hibernateprojectdemo.domain.Question;
import lombok.*;

@Getter
@Setter
@ToString
public class QuestionJdbc extends Question {
}
