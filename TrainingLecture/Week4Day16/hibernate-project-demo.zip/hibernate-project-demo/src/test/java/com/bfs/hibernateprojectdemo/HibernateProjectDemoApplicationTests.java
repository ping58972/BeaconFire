package com.bfs.hibernateprojectdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateProjectDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
