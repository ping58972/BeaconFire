package com.beaconfire.quizrestful.dao.hibernate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class UserDaoHibernateImplTest {


    @BeforeEach
    void setUp() {
    }

    @Test
    void getCurrentSession() {
    }

    @Test
    void setClazz() {
        assertTrue(true);
    }

    @Test
    void getAll() {
        assertTrue(true);
    }

    @Test
    void findById() {
        assertTrue(true);
    }

    @Test
    void add() {
        assertTrue(true);
    }

    @Test
    void getAllUsers() {
        assertTrue(true);
    }

    @Test
    void getUserById(){
        assertTrue(true);
    }

    @Test
    void createNewUser() {
        assertTrue(true);
    }

    @Test
    void deleteUserById() {
        assertTrue(true);
    }

    @Test
    void changeUserStatus() {
        assertTrue(true);
    }
}