package com.beaconfire.quizrestful.exception;

public class QuizNotFoundException extends Exception{
    public QuizNotFoundException(String message) {
        super(message);
    }
}
