package com.beaconfire.quizrestful.exception;

public class QuestionNotFoundException extends Exception{
    public QuestionNotFoundException(String message) {
        super(message);
    }
}
