package com.beaconfire.asynchronous;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsynchronousApplicationTests {

    @Test
    void contextLoads() {
    }

}
