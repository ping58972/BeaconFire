package com.example.jspdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JspdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
