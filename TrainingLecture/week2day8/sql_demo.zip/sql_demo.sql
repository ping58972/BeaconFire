CREATE DATABASE IF NOT EXISTS sql_demo1;
USE sql_demo1;

CREATE TABLE IF NOT EXISTS Caretaker (
	caretaker_id int primary key,
    firstname varchar(24),
    lastname varchar(24),
    phone long
);

describe caretaker;

select * from caretaker;
select firstname, phone from caretaker;

TRUNCATE TABLE caretaker;
DROP TABLE caretaker;

INSERT INTO Caretaker VALUES (1, 'abc', 'def', 123);

INSERT INTO Caretaker (caretaker_id, phone, firstname, lastname) VALUES 
(2, 222, 'aaaa', 'bbbb'),
(3, 333, 'cccc', 'dddd');

UPDATE Caretaker
SET phone = 123456789
WHERE firstname = 'abc' AND lastname = 'def';

DELETE FROM Caretaker WHERE caretaker_id = 1;

CREATE TABLE Zoo (
	zoo_id int primary key,
    zoo_name varchar(24),
    location varchar(24),
    caretaker_fk int,
    FOREIGN KEY (caretaker_fk) references Caretaker(caretaker_id)
);

drop table Zoo;

CREATE TABLE IF NOT EXISTS Animal (
	animal_id int PRIMARY KEY,
    species varchar(24), -- string up to 24 characters
    class varchar(24),
    age int,
    zoo_fk int,
    FOREIGN KEY (zoo_fk) references Zoo(zoo_id)
);

describe animal;
ALTER TABLE Animal ADD favorite_food varchar(24);


