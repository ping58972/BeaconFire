import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

class TestThreadClass1 extends Thread {
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName());
    }
}

class TestThreadClass2 implements Runnable{
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName());
    }
}

public class Driver {

    public static void main(String[] args) throws InterruptedException {
        // Two ways to create new Thread

//        System.out.println(Thread.currentThread().getName());

//        Thread t1 = new TestThreadClass1();
//		t1.start();
//        t1.run();
//		t1.start();

//		Thread t2 = new Thread(new TestThreadClass2());
//		t2.start();

//		Thread t3 = new Thread( () -> {
//			System.out.println(Thread.currentThread().getName());
//			});
//		t3.start();

//		t1.run();
//		t1.run();
//		t2.run();
//		t3.run();

        // Main thread
//		System.out.println(Thread.currentThread().getName());

        // Sleep
//		Thread t4 = new Thread(() -> {
//			try {
//				Thread.sleep(5000);
//				System.out.println(Thread.currentThread().getName() + " slept for 5 sec.");
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		});
//
//		Thread t5 = new Thread(() -> {
//			System.out.println(Thread.currentThread().getName());
//		});
//
//		t4.start();
//		t5.start();

        // Join
//		Thread t6 = new Thread(() -> {
//			try {
//				Thread.sleep(5000);
//				System.out.println(Thread.currentThread().getName() + " slept for 5 sec.");
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		});
//
//		Thread t7 = new Thread(() -> {
//			try {
//				t6.join();
//				System.out.println(Thread.currentThread().getName());
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		});
//
//		t6.start();
//		t7.start();

        // Daemon Thread
//        Thread daemonThread = new Thread(() -> {
//            try {
//                Thread.sleep(2000);
//                System.out.println("In daemon thread.");
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        });
//        daemonThread.setDaemon(true);
//        daemonThread.start();
//
////        Thread.sleep(5000);
//
//        System.out.println(Thread.currentThread().getName());

        // Counter example
//		Counter counter = new Counter();
//
//		Thread t1 = new Thread(() -> {
//			counter.increment();
//		});
//
//		Thread t2 = new Thread(() -> {
//			counter.decrement();
//		});
//
//
//		t1.start();
//		t2.start();
//
//		t1.join();
//		t2.join();
//
//		System.out.println(counter.value());

        // wait(), notify(), notifyAll()
//        TwoStepTask task = new TwoStepTask();
//        new Thread(() -> {task.firstStep();}).start();
//        new Thread(() -> {task.secondStep();}).start();
//        new Thread(() -> {task.anotherSecondStep();}).start();


        // ConcurrentHashMap
//		Map<Integer , String> map = new HashMap<>();
////		Map<Integer, String> syncMap = Collections.synchronizedMap(map);
//		ConcurrentHashMap<Integer, String> concurrentMap = new ConcurrentHashMap<>();
//		Thread t1 = new Thread( () -> {
//            for (int i = 0; i < 10000; i++){
//                concurrentMap.put(i, i+"");
//            }
//		});
//
//		Thread t2 = new Thread( () -> {
//            for (int i = 0; i < 10000; i++){
//                concurrentMap.put(i, i+"");
//            }
//		});
//
//		t1.start();
//		t2.start();
//
//		t1.join();
//		t2.join();
//
//		System.out.println(concurrentMap.size());


        // Deadlock
		Object key1 = new Object();
		Object key2 = new Object();

		Thread t8 = new Thread( () -> {
			synchronized (key1) {
				System.out.println("t8 has key 1.");
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				synchronized (key2) {
					System.out.println("t8 has key 2.");
				}
			}
		});

		Thread t9 = new Thread( () -> {
			synchronized (key2) {
				System.out.println("t9 has key 2.");
				synchronized (key1) {
					System.out.println("t9 has key 1.");
				}
			}
		});

		t8.start();
		t9.start();

    }

}

class Counter {
    private int c = 0;

    public synchronized void increment() {
        for (int i = 0; i < 10000; i++) {
            c++;
        }
    }

    public void decrement() {
        synchronized (this) {
            for (int i = 0; i < 10000; i++) {
                c--;
            }
        }
    }

    public int value() {
        return c;
    }
}

class TwoStepTask{
    private boolean firstStepDone = false;

    public synchronized void firstStep(){
        System.out.println("First step is executing");
        this.firstStepDone = true;
        System.out.println("First step is finished");
        this.notify();
    }

    public synchronized void secondStep(){
        System.out.println("Second step is executing");
        if (!firstStepDone){
            try {
                System.out.println("Second step is waiting for first step to complete");
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Second step is finished");

    }

    public synchronized void anotherSecondStep(){
        System.out.println("Another second step is executing");
        if (!firstStepDone){
            try {
                System.out.println("Another second step is waiting for first step to complete");
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Another second step is finished");
    }
}

