package com.bfs.compositiveservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompositiveServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
