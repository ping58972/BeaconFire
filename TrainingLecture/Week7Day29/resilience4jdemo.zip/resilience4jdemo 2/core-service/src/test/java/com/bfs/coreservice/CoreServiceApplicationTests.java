package com.bfs.coreservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
