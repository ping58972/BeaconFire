package com.beaconfire.springaop.ProxyDemo;

public interface Person {
    void getAJob();
}
