package com.beaconfire.springaop.AOPDemo.exception;

public class DemoNotFoundException extends Exception{
    public DemoNotFoundException(String s) {
        super(s);
    }
}
