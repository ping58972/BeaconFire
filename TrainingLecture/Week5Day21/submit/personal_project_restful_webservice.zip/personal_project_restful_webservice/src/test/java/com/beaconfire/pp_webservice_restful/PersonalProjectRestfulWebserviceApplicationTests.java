package com.beaconfire.pp_webservice_restful;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalProjectRestfulWebserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
