package com.beaconfire.pp_webservice_restful.exception;

public class QuizNotFoundException extends Exception{
    public QuizNotFoundException(String message) {
        super(message);
    }
}
