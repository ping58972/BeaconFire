package com.beaconfire.jdbctemplatedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcTemplateDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
