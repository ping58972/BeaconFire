package com.beaconfire.housingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HousingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
