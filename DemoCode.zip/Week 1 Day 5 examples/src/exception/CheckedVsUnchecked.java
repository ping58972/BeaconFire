package exception;

import java.io.BufferedReader;
import java.io.FileReader;

public class CheckedVsUnchecked {

    public static void main(String[] args) {

        // checked exception
//        Class temp = Class.forName("InvalidClass");

        // unchecked exception
//        int val = 7 / 0;
    }
}
