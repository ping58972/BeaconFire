package domain;

public interface Quiz {
}
