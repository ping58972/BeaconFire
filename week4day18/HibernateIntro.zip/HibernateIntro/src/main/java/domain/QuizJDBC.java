package domain;

public class QuizJDBC implements Quiz{
}
