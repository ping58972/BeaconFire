package domain;

public class QuizHibernate implements Quiz{
}
