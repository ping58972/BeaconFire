package dao;

public class QuizDAOHibernate implements QuizDAO{
}
