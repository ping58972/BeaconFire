package dao;

public class QuizDAOJdbc implements QuizDAO{
}
