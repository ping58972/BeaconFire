package dao;

import domain.Quiz;

public interface QuizDAO {

    List<Quiz> getAllQuizzes();



}
